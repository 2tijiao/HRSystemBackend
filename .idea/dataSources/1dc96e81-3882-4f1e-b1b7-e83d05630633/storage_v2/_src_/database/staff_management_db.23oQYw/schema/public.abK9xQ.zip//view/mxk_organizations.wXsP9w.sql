create view mxk_organizations
            (id, orgcode, orgname, fullname, parentid, parentcode, parentname, type, sortindex, status, instid,
             originid, description)
as
SELECT d.dept_id::character varying AS id,
       d.dept_number                AS orgcode,
       d.dept_name                  AS orgname,
       d.dept_name                  AS fullname,
       CASE
           WHEN d.parent_id = 0 THEN '1'::character varying
           ELSE d.parent_id::character varying
           END                      AS parentid,
       CASE
           WHEN d.parent_id = 0 THEN 'root'::character varying
           ELSE p.dept_number
           END                      AS parentcode,
       CASE
           WHEN d.parent_id = 0 THEN 'Root'::character varying
           ELSE p.dept_name
           END                      AS parentname,
       'department'::text           AS type,
       d.order_num                  AS sortindex,
       CASE
           WHEN d.status = '0'::bpchar THEN 1
           ELSE 2
           END                      AS status,
       '1'::text                    AS instid,
       d.dept_id::character varying AS originid,
       d.leader                     AS description
FROM sys_dept d
         LEFT JOIN sys_dept p ON d.parent_id = p.dept_id
WHERE d.del_flag = '0'::bpchar;

alter table mxk_organizations
    owner to postgres;

