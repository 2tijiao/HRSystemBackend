create view mxk_userinfo
            (id, username, usertype, windowsaccount, displayname, nickname, namezhspell, namezhshortspell, givenname,
             middlename, familyname, gender, authntype, mobile, email, workemail, workphonenumber, employeenumber,
             division, costcenter, organization, departmentid, department, jobtitle, joblevel, createdby, createddate,
             modifiedby, modifieddate, status, password, instid, sortindex)
as
SELECT u.user_id::character varying                          AS id,
       u.user_name                                           AS username,
       u.user_type::character varying                        AS usertype,
       NULL::character varying                               AS windowsaccount,
       u.nick_name                                           AS displayname,
       u.nick_name                                           AS nickname,
       NULL::character varying                               AS namezhspell,
       NULL::character varying                               AS namezhshortspell,
       s.name                                                AS givenname,
       NULL::character varying                               AS middlename,
       NULL::character varying                               AS familyname,
       CASE
           WHEN u.sex = '0'::bpchar THEN 1
           WHEN u.sex = '1'::bpchar THEN 2
           ELSE 0
           END                                               AS gender,
       NULL::character varying                               AS authntype,
       u.phonenumber                                         AS mobile,
       u.email,
       NULL::character varying                               AS workemail,
       NULL::character varying                               AS workphonenumber,
       s.employee_number                                     AS employeenumber,
       NULL::character varying                               AS division,
       NULL::character varying                               AS costcenter,
       NULL::character varying                               AS organization,
       '1196453494698016768'::character varying              AS departmentid,
       '广东盈浩工艺制品有限公司'::character varying         AS department,
       p.post_name                                           AS jobtitle,
       NULL::character varying                               AS joblevel,
       u.create_by::character varying                        AS createdby,
       to_char(u.create_time, 'YYYY-MM-DD HH24:MI:SS'::text) AS createddate,
       u.update_by::character varying                        AS modifiedby,
       to_char(u.update_time, 'YYYY-MM-DD HH24:MI:SS'::text) AS modifieddate,
       CASE
           WHEN u.status = '0'::bpchar THEN 1
           ELSE 0
           END                                               AS status,
       u.password,
       '1'::character varying                                AS instid,
       1                                                     AS sortindex
FROM sys_user u
         LEFT JOIN pro_staff s ON u.user_name::text = s.login_number::text
         LEFT JOIN sys_post p ON s.post_id = p.post_id
WHERE u.del_flag = '0'::bpchar;

alter table mxk_userinfo
    owner to postgres;

